namespace textparser;

public class IncrementalValues
{
    public string pName
    {
        get;
        set;
    }

    public int originYear
    {
        get;
        set;
    }

    public int developmentYear
    {
        get;
        set;
    }

    public double incremntalValue
    {
        get;
        set;
    }
}