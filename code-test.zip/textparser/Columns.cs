namespace textparser;

public class Columns
{
    public int ProductIndex
    {
        get;
        set;
    }
    
    public int OriginYearIndex
    {
        get;
        set;
    }
    
    public int DevYearIndex
    {
        get;
        set;
    }
    
        
    public int IncValIndex
    {
        get;
        set;
    }
    
}